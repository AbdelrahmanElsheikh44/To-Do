let todo = JSON.parse(localStorage.getItem("todo"))||[];
const Input = document.getElementById("Input");
const List = document.getElementById("List");
const Count = document.getElementById("Count");
const Button = document.querySelector(".button");

document.addEventListener("DOMContentLoaded", function () {
    Button.addEventListener("click", addTask);
    Input.addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
            event.preventDefault(); 
            addTask();
        }
    });
    displayTasks();
});
function saveToLocalStorage() {
    localStorage.setItem("todo", JSON.stringify(todo));
}

function addTask() {
    const newTask = Input.value.trim();
    if (newTask === "")return;
     {
        const text =  {text: newTask}
        todo.push(text);
        saveToLocalStorage();
        Input.value = "";
        displayTasks();
    }
}

function displayTasks() {
    List.innerHTML = "";
    todo.forEach((item, index) => {
        const li = document.createElement("li");
        li.className = "task-box";
        li.innerHTML = `
            <span class="todo-text" onclick="editTask(${index})">${item.text}</span>
            <div>
                <button class="edit-button" onclick="editTask(${index})"><i class="fa-solid fa-pen"></i></button>
                <button class="remove-button" onclick="removeTask(${index})"><i class="fa-solid fa-eraser"></i></button>
            </div>
        `;
        List.appendChild(li);
    });
    Count.textContent = todo.length;
}

function editTask(index) {
    const todoItem = document.querySelector(`.task-box:nth-child(${index + 1}) .todo-text`);
    const existingText = todo[index].text;

    const inputElement = document.createElement("input");
    inputElement.type = "text";
    inputElement.value = existingText;
    todoItem.textContent = ''; 
    todoItem.appendChild(inputElement); 
    inputElement.focus(); 

    inputElement.addEventListener("blur", function () {
        const updatedText = inputElement.value.trim();
        if (updatedText) {
            todo[index].text = updatedText; 
            saveToLocalStorage(); 
        }
        displayTasks(); 
    });

    inputElement.addEventListener("keypress", function (event) {
        if (event.key === "Enter") {
            inputElement.blur(); 
        }
    });
}


function removeTask(index) {
    todo.splice(index, 1);
    saveToLocalStorage();
    displayTasks();
}